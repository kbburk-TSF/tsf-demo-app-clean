# Daily Workflow Cheat Sheet

Aliases and Git/Docker usage.
