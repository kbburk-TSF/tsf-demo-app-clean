import React from 'react';

function SeasonalModels() {
  return <h2>Seasonal Models Preview</h2>;
}

export default SeasonalModels;
