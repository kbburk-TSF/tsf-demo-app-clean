import React from 'react';

function Dashboard() {
  return <h1>TSF Demo App Dashboard</h1>;
}

export default Dashboard;
